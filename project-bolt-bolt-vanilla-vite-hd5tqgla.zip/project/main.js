import './style.css';

const currentUser = {
  username: 'john',
  password: 'password123'
};

async function fetchHighestScores() {
  try {
    const response = await fetch('http://localhost:3001/api/highest-scores', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'username': currentUser.username,
        'password': currentUser.password
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    return data.data || [];
  } catch (error) {
    console.error('Error fetching scores:', error);
    return [];
  }
}

function calculateUserStats(scores = [], username) {
  const scoresArray = Array.isArray(scores) ? scores : [];
  
  const userScores = scoresArray.filter(score => score.username === username);
  const totalScore = userScores.reduce((sum, score) => sum + score.highest_score, 0);
  const averageScore = userScores.length ? (totalScore / userScores.length).toFixed(1) : 0;
  const bestScore = userScores.length ? Math.max(...userScores.map(s => s.highest_score)) : 0;
  
  return {
    totalScore,
    averageScore,
    bestScore,
    levelsCompleted: userScores.length
  };
}

function getMedalEmoji(rank) {
  if (rank === 1) return '<div class="medal medal-1">🥇</div>';
  if (rank === 2) return '<div class="medal medal-2">🥈</div>';
  if (rank === 3) return '<div class="medal medal-3">🥉</div>';
  return `<span class="rank">#${rank}</span>`;
}

async function initializeApp() {
  const scores = await fetchHighestScores();
  const userStats = calculateUserStats(scores, currentUser.username);

  document.querySelector('#app').innerHTML = `
    <div class="container">
      <div class="profile-card">
        <div class="profile-image">JD</div>
        <h2>John Doe</h2>
        <p>@${currentUser.username}</p>
        <div class="stats">
          <h3>Statistics</h3>
          <div class="stat-item">
            <span class="stat-label">Best Score</span>
            <span class="stat-value">${userStats.bestScore}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Average Score</span>
            <span class="stat-value">${userStats.averageScore}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Levels Completed</span>
            <span class="stat-value">${userStats.levelsCompleted}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">Total Score</span>
            <span class="stat-value">${userStats.totalScore}</span>
          </div>
        </div>
      </div>
      
      <div class="leaderboard">
        <h1>🏆 Leaderboard</h1>
        <table>
          <thead>
            <tr>
              <th>Rank</th>
              <th>Username</th>
              <th>Level</th>
              <th>Score</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            ${scores
              .sort((a, b) => b.highest_score - a.highest_score)
              .map((score, index) => `
                <tr class="score-row ${score.username === currentUser.username ? 'current-user' : ''}">
                  <td>${getMedalEmoji(index + 1)}</td>
                  <td>${score.username}</td>
                  <td>Level ${score.level}</td>
                  <td>${score.highest_score} pts</td>
                  <td>${score.time_taken}s</td>
                </tr>
              `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

initializeApp();