import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

async function initializeDb() {
  const db = await open({
    filename: './src/Db/quiz_database.db',
    driver: sqlite3.Database,
  });

  // Set busy timeout to 5 seconds (5000 milliseconds)
  await db.exec('PRAGMA busy_timeout = 5000;');

  // Drop existing tables
  await db.exec('DROP TABLE IF EXISTS users;');
  await db.exec('DROP TABLE IF EXISTS highest_scores;');
  await db.exec('DROP TABLE IF EXISTS leaderboard;');

  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      firstName TEXT NOT NULL,
      lastName TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS highest_scores (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      level INTEGER CHECK(level BETWEEN 1 AND 50),
      highest_score INTEGER CHECK(highest_score BETWEEN 0 AND 10),
      time_taken INTEGER,
      UNIQUE(username, level)
    );

    CREATE TABLE IF NOT EXISTS leaderboard (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      score INTEGER CHECK(score BETWEEN 0 AND 10)
    );
  `);

  // Insert initial user entries
  await db.run("INSERT OR IGNORE INTO users (firstName, lastName, email, username, password) VALUES (?, ?, ?, ?, ?)", ['John', 'Doe', 'john@example.com', 'john', 'password123']);
  await db.run("INSERT OR IGNORE INTO users (firstName, lastName, email, username, password) VALUES (?, ?, ?, ?, ?)", ['Jane', 'Smith', 'jane@example.com', 'jane', 'password123']);
  await db.run("INSERT OR IGNORE INTO users (firstName, lastName, email, username, password) VALUES (?, ?, ?, ?, ?)", ['Alice', 'Johnson', 'alice@example.com', 'alice', 'password123']);

  // Insert mock highest scores
  const mockScores = [
    ['john', 1, 8, 120],
    ['john', 2, 7, 150],
    ['jane', 1, 9, 100],
    ['jane', 2, 8, 130],
    ['alice', 1, 7, 140],
    ['alice', 2, 9, 110],
  ];

  for (const [username, level, score, time] of mockScores) {
    await db.run(
      "INSERT OR IGNORE INTO highest_scores (username, level, highest_score, time_taken) VALUES (?, ?, ?, ?)",
      [username, level, score, time]
    );
  }

  console.log("Database initialized with initial entries and mock scores.");
}

initializeDb().catch(err => {
  console.error("Error initializing database:", err);
});